class Solution(object):
    def convert(self, s, numRows):
        if numRows == 1 or numRows >= len(s):
            return s
        
        # Create an array of strings to store characters for each row
        rows = [''] * numRows
        # Initialize the index and direction variables
        index, direction = 0, 1
        
        # Iterate through each character in the input string
        for char in s:
            # Add the current character to the corresponding row
            rows[index] += char
            # If we are at the first or last row, change direction
            if index == 0:
                direction = 1
            elif index == numRows - 1:
                direction = -1
            # Update the index based on direction
            index += direction
        
        # Concatenate all rows to form the final converted string
        return ''.join(rows)

# Test cases
solution = Solution()
print(solution.convert("PAYPALISHIRING", 3))  # Output: "PAHNAPLSIIGYIR"
print(solution.convert("PAYPALISHIRING", 4))  # Output: "PINALSIGYAHRPI"
print(solution.convert("A", 1))              # Output: "A"
 