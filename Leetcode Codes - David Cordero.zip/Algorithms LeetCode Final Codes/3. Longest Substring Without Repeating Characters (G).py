class Solution(object):
    def lengthOfLongestSubstring(self, s):
        """
        :type s: str
        :rtype: int
        """
        # Initialize variables
        max_length = 0
        start = 0
        seen = set()
        
        # Iterate through the string
        for end in range(len(s)):
            # If the character at 'end' is already in the set,
            # move 'start' to the next position after the last occurrence of that character
            while s[end] in seen:
                seen.remove(s[start])
                start += 1
            
            # Add the character at 'end' to the set
            seen.add(s[end])
            
            # Update the maximum length
            max_length = max(max_length, end - start + 1)
        
        return max_length
