class Solution:
    def minimumTotal(self, triangle: List[List[int]]) -> int:
        # Starting from the second-to-last row and moving upwards
        for i in range(len(triangle) - 2, -1, -1):
            # Update each element in the current row with the minimum sum of the two adjacent elements from the row below
            for j in range(len(triangle[i])):
                triangle[i][j] += min(triangle[i + 1][j], triangle[i + 1][j + 1])
        
        # The minimum path sum will be at the top of the triangle
        return triangle[0][0]

# Test cases
solution = Solution()
print(solution.minimumTotal([[2],[3,4],[6,5,7],[4,1,8,3]]))  # Output: 11
print(solution.minimumTotal([[-10]]))                      # Output: -10
