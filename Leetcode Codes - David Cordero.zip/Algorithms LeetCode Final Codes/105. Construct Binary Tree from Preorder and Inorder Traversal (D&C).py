class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution:
    def buildTree(self, preorder, inorder):
        """
        :type preorder: List[int]
        :type inorder: List[int]
        :rtype: TreeNode
        """
        if not preorder or not inorder:
            return None
        
        # Construct a hashmap for quick lookup of indices in the inorder array
        inorder_map = {val: idx for idx, val in enumerate(inorder)}
        
        return self.build_tree_helper(preorder, 0, len(preorder) - 1, inorder, 0, len(inorder) - 1, inorder_map)
    
    def build_tree_helper(self, preorder, pre_start, pre_end, inorder, in_start, in_end, inorder_map):
        if pre_start > pre_end or in_start > in_end:
            return None
        
        # The root node is the first element of the preorder array
        root_val = preorder[pre_start]
        root = TreeNode(root_val)
        
        # Find the index of the root node in the inorder array
        root_idx_inorder = inorder_map[root_val]
        
        # Determine the size of the left subtree
        left_subtree_size = root_idx_inorder - in_start
        
        # Recursively construct the left and right subtrees
        root.left = self.build_tree_helper(preorder, pre_start + 1, pre_start + left_subtree_size, inorder, in_start, root_idx_inorder - 1, inorder_map)
        root.right = self.build_tree_helper(preorder, pre_start + left_subtree_size + 1, pre_end, inorder, root_idx_inorder + 1, in_end, inorder_map)
        
        return root

# Helper function to print the binary tree in preorder traversal
def print_tree_preorder(root):
    if root:
        print(root.val, end=" ")
        print_tree_preorder(root.left)
        print_tree_preorder(root.right)

# Test case
solution = Solution()
preorder = [3, 9, 20, 15, 7]
inorder = [9, 3, 15, 20, 7]
root = solution.buildTree(preorder, inorder)
print_tree_preorder(root)  # Output: 3 9 20 15 7
