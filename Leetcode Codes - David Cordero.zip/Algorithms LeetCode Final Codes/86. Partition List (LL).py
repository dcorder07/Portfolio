class ListNode(object):
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class Solution(object):
    def partition(self, head, x):
        """
        :type head: ListNode
        :type x: int
        :rtype: ListNode
        """
        # Initialize dummy nodes for two partitions
        before_head = ListNode(0)
        after_head = ListNode(0)
        
        # Initialize pointers for two partitions
        before = before_head
        after = after_head
        
        # Traverse the original list and partition nodes
        current = head
        while current:
            if current.val < x:
                before.next = current
                before = before.next
            else:
                after.next = current
                after = after.next
            current = current.next
        
        # Connect the two partitions and set the end of after partition to None
        after.next = None
        before.next = after_head.next
        
        return before_head.next

# Helper function to create linked list from array
def create_linked_list(arr):
    if not arr:
        return None
    head = ListNode(arr[0])
    current = head
    for val in arr[1:]:
        current.next = ListNode(val)
        current = current.next
    return head

# Helper function to print linked list
def print_linked_list(head):
    current = head
    while current:
        print(current.val),
        if current.next:
            print("->"),
        current = current.next
    print("None")

# Test cases
solution = Solution()
head_1 = create_linked_list([1, 4, 3, 2, 5, 2])
x_1 = 3
print_linked_list(solution.partition(head_1, x_1))  # Output: 1 -> 2 -> 2 -> 4 -> 3 -> 5 -> None

head_2 = create_linked_list([2, 1])
x_2 = 2
print_linked_list(solution.partition(head_2, x_2))  # Output: 1 -> 2 -> None
