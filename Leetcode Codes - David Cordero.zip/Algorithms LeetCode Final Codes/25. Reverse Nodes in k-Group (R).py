# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

class Solution(object):
    def reverseKGroup(self, head, k):
        """
        :type head: ListNode
        :type k: int
        :rtype: ListNode
        """
        # Helper function to reverse a linked list from start to end
        def reverse(start, end):
            prev, curr = None, start
            while curr != end:
                next_node = curr.next
                curr.next = prev
                prev = curr
                curr = next_node
            return prev
        
        # Initialize pointers for traversal
        count = 0
        curr = head
        
        # Move curr to the k+1 node or the end of the list
        while curr and count < k:
            curr = curr.next
            count += 1
        
        # If there are at least k nodes, reverse them and recursively call the function for the next group
        if count == k:
            reversed_head = reverse(head, curr)
            head.next = self.reverseKGroup(curr, k)
            return reversed_head
        # If there are fewer than k nodes, no need to reverse, return head as is
        else:
            return head
