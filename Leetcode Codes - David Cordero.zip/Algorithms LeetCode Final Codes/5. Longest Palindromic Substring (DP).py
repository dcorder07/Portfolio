class Solution(object):
    def longestPalindrome(self, s):
        """
        :type s: str
        :rtype: str
        """
        if len(s) < 2:
            return s
        
        # Initialize variables to store the start and end indices of the longest palindrome
        start = 0
        end = 0
        
        for i in range(len(s)):
            # Check for odd-length palindromes with center at s[i]
            len1 = self.expandAroundCenter(s, i, i)
            
            # Check for even-length palindromes with center between s[i] and s[i+1]
            len2 = self.expandAroundCenter(s, i, i + 1)
            
            # Update the start and end indices if we find a longer palindrome
            max_len = max(len1, len2)
            if max_len > end - start:
                start = i - (max_len - 1) // 2
                end = i + max_len // 2
        
        # Return the longest palindrome substring
        return s[start:end+1]
    
    def expandAroundCenter(self, s, left, right):
        """
        Helper function to expand around the center and find the length of the palindrome.
        """
        while left >= 0 and right < len(s) and s[left] == s[right]:
            left -= 1
            right += 1
        return right - left - 1
