class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

class Solution:
    def sortList(self, head: ListNode) -> ListNode:
        if not head or not head.next:
            return head
        
        # Step 1: Split the linked list into two halves
        slow = head
        fast = head.next
        
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        
        second_half = slow.next
        slow.next = None
        
        # Step 2: Recursively sort each half
        first_half = self.sortList(head)
        second_half = self.sortList(second_half)
        
        # Step 3: Merge the sorted halves
        dummy = ListNode(0)
        curr = dummy
        
        while first_half and second_half:
            if first_half.val < second_half.val:
                curr.next = first_half
                first_half = first_half.next
            else:
                curr.next = second_half
                second_half = second_half.next
            curr = curr.next
        
        if first_half:
            curr.next = first_half
        else:
            curr.next = second_half
        
        return dummy.next

# Test cases
solution = Solution()

# Example 1
head1 = ListNode(4)
head1.next = ListNode(2)
head1.next.next = ListNode(1)
head1.next.next.next = ListNode(3)
sorted_head1 = solution.sortList(head1)
while sorted_head1:
    print(sorted_head1.val, end=" -> ")
    sorted_head1 = sorted_head1.next
print()

# Example 2
head2 = ListNode(-1)
head2.next = ListNode(5)
head2.next.next = ListNode(3)
head2.next.next.next = ListNode(4)
head2.next.next.next.next = ListNode(0)
sorted_head2 = solution.sortList(head2)
while sorted_head2:
    print(sorted_head2.val, end=" -> ")
    sorted_head2 = sorted_head2.next
print()
