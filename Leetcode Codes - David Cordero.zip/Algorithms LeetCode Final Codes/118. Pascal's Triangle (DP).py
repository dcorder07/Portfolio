class Solution:
    def generate(self, numRows: int) -> List[List[int]]:
        if numRows == 0:
            return []
        
        triangle = [[1]]  # Base case: first row is [1]
        
        for i in range(1, numRows):
            prev_row = triangle[i - 1]
            new_row = [1]  # First element of the row is always 1
            
            for j in range(1, i):
                # Calculate the new element by adding the two elements above it
                new_element = prev_row[j - 1] + prev_row[j]
                new_row.append(new_element)
            
            new_row.append(1)  # Last element of the row is always 1
            triangle.append(new_row)
        
        return triangle

# Test cases
solution = Solution()
print(solution.generate(5))  # Output: [[1],[1,1],[1,2,1],[1,3,3,1],[1,4,6,4,1]]
print(solution.generate(1))  # Output: [[1]]
