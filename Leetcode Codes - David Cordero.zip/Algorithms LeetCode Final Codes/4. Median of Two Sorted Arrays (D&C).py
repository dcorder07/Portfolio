class Solution(object):
    def findMedianSortedArrays(self, nums1, nums2):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :rtype: float
        """
        total_length = len(nums1) + len(nums2)
        if total_length % 2 == 0:
            # If the total number of elements is even
            return (self.findKthElement(nums1, nums2, total_length // 2) + self.findKthElement(nums1, nums2, total_length // 2 - 1)) / 2.0
        else:
            # If the total number of elements is odd
            return self.findKthElement(nums1, nums2, total_length // 2)
    
    def findKthElement(self, nums1, nums2, k):
        """
        Helper function to find the kth element in the merged sorted array of nums1 and nums2.
        """
        # Base cases
        if not nums1:
            return nums2[k]
        if not nums2:
            return nums1[k]
        if k == 0:
            return min(nums1[0], nums2[0])
        
        # Calculate mid indices for nums1 and nums2
        mid1 = len(nums1) // 2
        mid2 = len(nums2) // 2
        
        if mid1 + mid2 < k:
            # If the sum of mid indices is less than k,
            # we discard the smaller half of the arrays and update k
            if nums1[mid1] > nums2[mid2]:
                return self.findKthElement(nums1, nums2[mid2 + 1:], k - mid2 - 1)
            else:
                return self.findKthElement(nums1[mid1 + 1:], nums2, k - mid1 - 1)
        else:
            # If the sum of mid indices is greater than or equal to k,
            # we discard the larger half of the arrays and update k
            if nums1[mid1] > nums2[mid2]:
                return self.findKthElement(nums1[:mid1], nums2, k)
            else:
                return self.findKthElement(nums1, nums2[:mid2], k)
