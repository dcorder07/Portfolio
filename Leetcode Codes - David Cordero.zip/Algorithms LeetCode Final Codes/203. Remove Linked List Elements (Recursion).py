class Solution:
    def removeElements(self, head: Optional[ListNode], val: int) -> Optional[ListNode]:
        # Handle edge case where the head is None
        while head and head.val == val:
            head = head.next
        
        # Return if head is None
        if not head:
            return None
        
        current = head
        
        while current.next:
            if current.next.val == val:
                current.next = current.next.next
            else:
                current = current.next
        
        return head
