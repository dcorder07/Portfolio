import heapq

class Solution(object):
    def mergeKLists(self, lists):
        """
        :type lists: List[ListNode]
        :rtype: ListNode
        """
        # Define a ListNode class to simplify coding
        class ListNode:
            def __init__(self, val=0, next=None):
                self.val = val
                self.next = next
        
        # Initialize the priority queue (min heap)
        heap = []
        for i, node in enumerate(lists):
            if node:  # Push non-empty lists into the heap
                heapq.heappush(heap, (node.val, i, node))
        
        # Initialize the dummy node for the result
        dummy = ListNode()
        current = dummy
        
        # Merge lists using min heap
        while heap:
            val, idx, node = heapq.heappop(heap)
            current.next = node
            current = current.next
            if node.next:  # Push the next node of the current list into the heap
                heapq.heappush(heap, (node.next.val, idx, node.next))
        
        return dummy.next
    
    
