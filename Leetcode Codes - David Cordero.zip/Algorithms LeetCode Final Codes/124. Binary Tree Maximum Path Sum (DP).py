class Solution:
    def maxPathSum(self, root: TreeNode) -> int:
        # Helper function to find the maximum path sum at each node
        def max_path_sum(node):
            nonlocal max_sum
            if not node:
                return 0
            
            # Find the maximum path sum in the left and right subtrees
            left_sum = max(max_path_sum(node.left), 0)
            right_sum = max(max_path_sum(node.right), 0)
            
            # Update the maximum path sum found so far
            max_sum = max(max_sum, node.val + left_sum + right_sum)
            
            # Return the maximum path sum that includes the current node
            return node.val + max(left_sum, right_sum)
        
        max_sum = float('-inf')
        max_path_sum(root)
        return max_sum

# Test cases
solution = Solution()
root1 = TreeNode(1)
root1.left = TreeNode(2)
root1.right = TreeNode(3)
print(solution.maxPathSum(root1))  # Output: 6

root2 = TreeNode(-10)
root2.left = TreeNode(9)
root2.right = TreeNode(20)
root2.right.left = TreeNode(15)
root2.right.right = TreeNode(7)
print(solution.maxPathSum(root2))  # Output: 42
