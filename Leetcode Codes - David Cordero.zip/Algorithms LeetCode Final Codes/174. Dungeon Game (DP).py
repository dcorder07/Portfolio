class Solution:
    def calculateMinimumHP(self, dungeon: List[List[int]]) -> int:
        m, n = len(dungeon), len(dungeon[0])
        dp = [[0] * n for _ in range(m)]
        
        # Calculate the minimum initial health required for the last cell
        dp[m - 1][n - 1] = max(1, 1 - dungeon[m - 1][n - 1])
        
        # Fill the last column
        for i in range(m - 2, -1, -1):
            dp[i][n - 1] = max(1, dp[i + 1][n - 1] - dungeon[i][n - 1])
        
        # Fill the last row
        for j in range(n - 2, -1, -1):
            dp[m - 1][j] = max(1, dp[m - 1][j + 1] - dungeon[m - 1][j])
        
        # Fill the remaining cells
        for i in range(m - 2, -1, -1):
            for j in range(n - 2, -1, -1):
                dp[i][j] = max(1, min(dp[i + 1][j], dp[i][j + 1]) - dungeon[i][j])
        
        return dp[0][0]

# Test cases
solution = Solution()

# Example 1
print(solution.calculateMinimumHP([[-2,-3,3],[-5,-10,1],[10,30,-5]]))   # Output: 7

# Example 2
print(solution.calculateMinimumHP([[0]]))   # Output: 1
