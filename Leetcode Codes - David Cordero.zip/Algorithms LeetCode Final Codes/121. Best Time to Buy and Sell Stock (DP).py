class Solution:
    def maxProfit(self, prices: List[int]) -> int:
        if not prices:
            return 0
        
        min_price = prices[0]  # Initialize the minimum price
        max_profit = 0
        
        for price in prices:
            min_price = min(min_price, price)  # Update the minimum price seen so far
            max_profit = max(max_profit, price - min_price)  # Update the maximum profit
        
        return max_profit

# Test cases
solution = Solution()
print(solution.maxProfit([7,1,5,3,6,4]))  # Output: 5
print(solution.maxProfit([7,6,4,3,1]))    # Output: 0
