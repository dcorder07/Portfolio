class Solution:
    def numDistinct(self, s: str, t: str) -> int:
        # Initialize the dp table
        dp = [[0] * (len(t) + 1) for _ in range(len(s) + 1)]
        
        # Base case: if t is empty, there is exactly one subsequence of s that equals t
        for i in range(len(s) + 1):
            dp[i][0] = 1
        
        # Fill the dp table
        for i in range(1, len(s) + 1):
            for j in range(1, len(t) + 1):
                if s[i - 1] == t[j - 1]:
                    dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j]
                else:
                    dp[i][j] = dp[i - 1][j]
        
        return dp[len(s)][len(t)]

# Test cases
solution = Solution()
print(solution.numDistinct("rabbbit", "rabbit"))  # Output: 3
print(solution.numDistinct("babgbag", "bag"))     # Output: 5
