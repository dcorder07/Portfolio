class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution:
    def sortedArrayToBST(self, nums):
        """
        :type nums: List[int]
        :rtype: TreeNode
        """
        if not nums:
            return None
        
        return self.construct_bst(nums, 0, len(nums) - 1)
    
    def construct_bst(self, nums, left, right):
        if left > right:
            return None
        
        # Find the middle element of the array
        mid = left + (right - left) // 2
        
        # Construct the root node
        root = TreeNode(nums[mid])
        
        # Recursively construct the left and right subtrees
        root.left = self.construct_bst(nums, left, mid - 1)
        root.right = self.construct_bst(nums, mid + 1, right)
        
        return root

# Helper function to print the binary tree in inorder traversal
def print_tree_inorder(root):
    if root:
        print_tree_inorder(root.left)
        print(root.val, end=" ")
        print_tree_inorder(root.right)

# Test cases
solution = Solution()
nums1 = [-10, -3, 0, 5, 9]
root1 = solution.sortedArrayToBST(nums1)
print_tree_inorder(root1)  # Output: -10 -3 0 5 9

print()

nums2 = [1, 3]
root2 = solution.sortedArrayToBST(nums2)
print_tree_inorder(root2)  # Output: 1 3
