class Solution(object):
    def reverse(self, x):
        """
        :type x: int
        :rtype: int
        """
        # Define the upper and lower bounds of a 32-bit signed integer
        INT_MAX = 2**31 - 1
        INT_MIN = -2**31
        
        # Initialize the result variable to store the reversed number
        result = 0
        # Save the sign of x
        sign = 1 if x >= 0 else -1
        # Take the absolute value of x
        x = abs(x)
        
        # Reverse the digits
        while x != 0:
            digit = x % 10  # Extract the least significant digit
            # Check for integer overflow
            if result > (INT_MAX - digit) // 10:
                return 0
            # Update the reversed number
            result = result * 10 + digit
            # Move to the next digit
            x //= 10
        
        # Apply the original sign
        result *= sign
        
        # Check for overflow/underflow
        if result < INT_MIN or result > INT_MAX:
            return 0
        
        return result

# Test cases
solution = Solution()
print(solution.reverse(123))   # Output: 321
print(solution.reverse(-123))  # Output: -321
print(solution.reverse(120))   # Output: 21
