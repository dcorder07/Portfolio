# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next

class Solution(object):
    def swapPairs(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        # Base case: if the list is empty or has only one node
        if not head or not head.next:
            return head
        
        # Swap the first two nodes
        first = head
        second = head.next
        first.next = self.swapPairs(second.next)
        second.next = first
        
        # Return the new head (second node after swapping)
        return second
