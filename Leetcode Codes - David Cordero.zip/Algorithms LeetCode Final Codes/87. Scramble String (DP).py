class Solution(object):
    def isScramble(self, s1, s2):
        """
        :type s1: str
        :type s2: str
        :rtype: bool
        """
        if len(s1) != len(s2):
            return False
        
        if s1 == s2:
            return True
        
        n = len(s1)
        
        # Initialize a 3D DP table to memoize the results
        dp = [[[False] * (n + 1) for _ in range(n)] for _ in range(n)]
        
        # Base case: strings of length 1
        for i in range(n):
            for j in range(n):
                dp[i][j][1] = s1[i] == s2[j]
        
        # Fill the DP table using bottom-up approach
        for length in range(2, n + 1):
            for i in range(n - length + 1):
                for j in range(n - length + 1):
                    for k in range(1, length):
                        if (dp[i][j][k] and dp[i + k][j + k][length - k]) or (dp[i][j + length - k][k] and dp[i + k][j][length - k]):
                            dp[i][j][length] = True
                            break
        
        return dp[0][0][n]

# Test cases
solution = Solution()
print(solution.isScramble("great", "rgeat"))  # Output: True
print(solution.isScramble("abcde", "caebd"))  # Output: False
print(solution.isScramble("a", "a"))  # Output: True
