# Definition for a binary tree node.
class TreeNode(object):
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution(object):
    def generateTrees(self, n):
        """
        :type n: int
        :rtype: List[TreeNode]
        """
        if n == 0:
            return []
        
        return self.generate_trees_helper(1, n)
    
    def generate_trees_helper(self, start, end):
        if start > end:
            return [None]
        
        all_trees = []
        for i in range(start, end + 1):
            left_subtrees = self.generate_trees_helper(start, i - 1)
            right_subtrees = self.generate_trees_helper(i + 1, end)
            
            for left_tree in left_subtrees:
                for right_tree in right_subtrees:
                    root = TreeNode(i)
                    root.left = left_tree
                    root.right = right_tree
                    all_trees.append(root)
        
        return all_trees

# Helper function to print all possible BSTs
def print_trees(trees):
    for tree in trees:
        print_tree(tree)
        print()

# Helper function to print a single BST
def print_tree(root, level=0):
    if root:
        print_tree(root.right, level + 1)
        print(" " * 4 * level + "->", root.val)
        print_tree(root.left, level + 1)

# Test cases
solution = Solution()
trees_1 = solution.generateTrees(3)
print_trees(trees_1)

trees_2 = solution.generateTrees(1)
print_trees(trees_2)
