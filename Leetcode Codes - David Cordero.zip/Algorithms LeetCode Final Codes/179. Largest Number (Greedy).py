class Solution:
    def largestNumber(self, nums: List[int]) -> str:
        # Custom comparison function
        def compare(a, b):
            return int(b + a) - int(a + b)
        
        # Convert numbers to strings
        nums = [str(num) for num in nums]
        
        # Sort using custom comparison function
        nums.sort(key=cmp_to_key(compare))
        
        # Concatenate the sorted strings
        largest_num = ''.join(nums)
        
        # Handle edge case where the largest number is 0
        if largest_num[0] == '0':
            return '0'
        
        return largest_num

# Test cases
solution = Solution()

# Example 1
print(solution.largestNumber([10, 2]))  # Output: "210"

# Example 2
print(solution.largestNumber([3, 30, 34, 5, 9]))  # Output: "9534330"
